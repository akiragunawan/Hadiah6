package com.example.tlms.hadiah6;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
   TextView dataa;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        dataa = (TextView) findViewById(R.id.hasil);
        dataa.setText(String.valueOf(getIntent().getDoubleExtra("data1",0)));
    }



}
