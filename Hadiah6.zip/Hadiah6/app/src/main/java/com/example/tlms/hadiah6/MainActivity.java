package com.example.tlms.hadiah6;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn1;
    Button btn2;
    EditText txt1;
    EditText txt2;
    double n1, n2 , hasiltambah, hasilkurang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 =  (Button) findViewById(R.id.btn2);
        txt1 = (EditText) findViewById(R.id.edt1);
        txt2 = (EditText) findViewById(R.id.edt2);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                n1 = Double.parseDouble(txt1.getText().toString());
                n2 = Double.parseDouble(txt2.getText().toString());
                hasiltambah = n1+n2;

                Intent intent1 = new Intent(MainActivity.this, Main2Activity.class);
                intent1.putExtra("data1", hasiltambah);

                startActivity(intent1);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                n1 = Double.parseDouble(txt1.getText().toString());
                n2 = Double.parseDouble(txt2.getText().toString());
                if(n2 < n1){
                     Toast.makeText(MainActivity.this,"Nilai 2 lebih kecil dari pada Nilai 1",Toast.LENGTH_SHORT).show();
                }else{
                hasilkurang = n2-n1;

                Intent intent2 = new Intent(MainActivity.this, Main2Activity.class);
                intent2.putExtra("data1", hasilkurang);

                startActivity(intent2);
            }}
        });

    }
}
